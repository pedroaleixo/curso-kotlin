

import kotlin.math.PI

    fun hello(){
        return println("Hello, world!")
    }

    fun sum(x: Int, y: Int): Int {
        return x + y
    }

    fun sum2(x: Int, y: Int) = x + y

    fun printMessageWithPrefix(message: String, prefix: String = "Info") {
        println("[$prefix] $message")
    }


    fun printMessage(message: String) {
        println(message)
        // `return Unit` or `return` is optional
    }

    fun toSeconds(time: String): (Int) -> Int = when (time) {
        "hour" -> { value -> value * 60 * 60 }
        "minute" -> { value -> value * 60 }
        "second" -> { value -> value }
        else -> { value -> value }
    }

    fun circleArea(radius: Int): Double {
        return PI * radius * radius
    }

    fun circleArea2(radius: Int): Double = PI * radius * radius

    fun uppercaseString(string: String): String {
        return string.uppercase()
    }

fun repeatN(n: Int, action: () -> Unit) {
    for (i in 1..n) {
        action()
    }
}



    fun main() {

        hello()
        println(sum(1, 2))

        println(sum2(1, 2))

        // Function called with both parameters
        printMessageWithPrefix("Hello", "Log")
        // [Log] Hello

        // Function called only with message parameter
        printMessageWithPrefix("Hello")
        // [Info] Hello

        printMessageWithPrefix(prefix = "Log", message = "Hello")
        // [Log] Hello

        printMessage("Hello")

        println(circleArea(2)) // 12.566370614359172

        println(circleArea2(2)) // 12.566370614359172

        println({ string: String -> string.uppercase() + "T" }("hello"))

        println(uppercaseString("hello"))

        println({ string: String -> string.uppercase() }("hello"))


        val upperCaseString2 = { string: String -> string.uppercase() }
        println(upperCaseString2("hello"))

        val numbers = listOf(1, -2, 3, -4, 5, -6)
        val positives = numbers.filter { x -> x > 0 }
        val negatives = numbers.filter { x -> x < 0 }
        val doubled = numbers.map { x -> x * 2 }
        val tripled = numbers.map { x -> x * 3 }
        println(positives)
// [1, 3, 5]
        println(negatives)
// [-2, -4, -6]

        println(doubled)
// [2, -4, 6, -8, 10, -12]
        println(tripled)
// [3, -6, 9, -12, 15, -18]

        val timesInMinutes = listOf(2, 10, 15, 1)
        val min2sec = toSeconds("minute")
        val totalTimeInSeconds = timesInMinutes.map(min2sec).sum()
        println("Total time is $totalTimeInSeconds secs")
        // Total time is 1680 secs

        // The initial value is zero.
// The operation sums the initial value with every item in the list cumulatively.
        println(listOf(1, 2, 3).fold(0, { x, item -> x + item })) // 6

// Alternatively, in the form of a trailing lambda
        println(listOf(1, 2, 3).fold(0) { x, item -> x + item })  // 6

        val actions = listOf("title", "year", "author")
        val prefix = "https://example.com/book-info"
        val id = 5
        val urls = actions.map { action -> "$prefix/$id/$action" }
        println(urls)

        repeatN(5) {
            println("Hello")
        }
    }