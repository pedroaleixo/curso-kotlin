
fun main() {
    //LIST
    // Read only list
    val readOnlyShapes = listOf("triangle", "square", "circle")
    println(readOnlyShapes)
// [triangle, square, circle]

// Mutable list with explicit type declaration
    val shapes: MutableList<String> = mutableListOf("triangle", "square", "circle")
    println(shapes)
// [triangle, square, circle]

    val shapes1: MutableList<String> = mutableListOf("triangle", "square", "circle")
    val shapesLocked1: List<String> = shapes

    val readOnlyShapes1 = listOf("triangle", "square", "circle")
    println("The first item in the list is: ${readOnlyShapes1[0]}")
// The first item in the list is: triangle

    val readOnlyShapes2 = listOf("triangle", "square", "circle")
    println("The first item in the list is: ${readOnlyShapes2.first()}")
// The first item in the list is: triangle

    val readOnlyShapes3 = listOf("triangle", "square", "circle")
    println("This list has ${readOnlyShapes3.count()} items")
// This list has 3 items

    val readOnlyShapes4 = listOf("triangle", "square", "circle")
    println("circle" in readOnlyShapes4)
// true


    val shapes2: MutableList<String> = mutableListOf("triangle", "square", "circle")
// Add "pentagon" to the list
    shapes2.add("pentagon")
    println(shapes2)
// [triangle, square, circle, pentagon]

// Remove the first "pentagon" from the list
    shapes2.remove("pentagon")
    println(shapes2)
// [triangle, square, circle]


    //SET
    // Read-only set
    val readOnlyFruit = setOf("apple", "banana", "cherry", "cherry")
// Mutable set with explicit type declaration
    val fruit: MutableSet<String> = mutableSetOf("apple", "banana", "cherry", "cherry")

    println(readOnlyFruit)


    val fruit1: MutableSet<String> = mutableSetOf("apple", "banana", "cherry", "cherry")
    val fruitLocked1: Set<String> = fruit1

    val fruit2: MutableSet<String> = mutableSetOf("apple", "banana", "cherry", "cherry")
    val fruitLocked2: Set<String> = fruit2

    val readOnlyFruit2 = setOf("apple", "banana", "cherry", "cherry")
    println("banana" in readOnlyFruit2)
// true


    val fruit3: MutableSet<String> = mutableSetOf("apple", "banana", "cherry", "cherry")
    fruit.add("dragonfruit")    // Add "dragonfruit" to the set
    println(fruit3)              // [apple, banana, cherry, dragonfruit]

    fruit3.remove("dragonfruit") // Remove "dragonfruit" from the set
    println(fruit3)              // [apple, banana, cherry]

    //MAP

    // Read-only map
    val readOnlyJuiceMenu = mapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
    println(readOnlyJuiceMenu)
// {apple=100, kiwi=190, orange=100}

// Mutable map with explicit type declaration
    val juiceMenu: MutableMap<String, Int> = mutableMapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
    println(juiceMenu)
// {apple=100, kiwi=190, orange=100}

    val juiceMenu1: MutableMap<String, Int> = mutableMapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
    val juiceMenuLocked: Map<String, Int> = juiceMenu1

    // Read-only map
    val readOnlyJuiceMenu2 = mapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
    println("The value of apple juice is: ${readOnlyJuiceMenu2["apple"]}")
// The value of apple juice is: 100


    // Read-only map
    val readOnlyJuiceMenu3 = mapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
    println("This map has ${readOnlyJuiceMenu3.count()} key-value pairs")
// This map has 3 key-value pairs

    val juiceMenu2: MutableMap<String, Int> = mutableMapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
    juiceMenu2.put("coconut", 150) // Add key "coconut" with value 150 to the map
    println(juiceMenu2)
// {apple=100, kiwi=190, orange=100, coconut=150}

    juiceMenu2.remove("orange")    // Remove key "orange" from the map
    println(juiceMenu2)
// {apple=100, kiwi=190, coconut=150}

    val readOnlyJuiceMenu4 = mapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
    println(readOnlyJuiceMenu4.containsKey("kiwi"))
// true

    val readOnlyJuiceMenu5 = mapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
    println(readOnlyJuiceMenu5.keys)
// [apple, kiwi, orange]
    println(readOnlyJuiceMenu5.values)
// [100, 190, 100]


    val readOnlyJuiceMenu6 = mapOf("apple" to 100, "kiwi" to 190, "orange" to 100)
    println("orange" in readOnlyJuiceMenu6.keys)
// true
    println(200 in readOnlyJuiceMenu6.values)
// false


    val greenNumbers = listOf(1, 4, 23)
    val redNumbers = listOf(17, 2)
    val totalCount = greenNumbers.count() + redNumbers.count()
    println(totalCount)


    val SUPPORTED = setOf("HTTP", "HTTPS", "FTP")
    val requested = "smtp"
    val isSupported = requested.uppercase() in SUPPORTED
    println("Support for $requested: $isSupported")

    val number2word = mapOf(1 to "one", 2 to "two", 3 to "three")
    val n = 2
    println("$n is spelt as '${number2word[n]}'")
}