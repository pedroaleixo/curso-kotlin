fun main() {

    val a: Int = 1000
    val b: String = "log message"
    val c: Double = 3.14
    val d: Long = 100_000_000_000
    val e: Boolean = false
    val f: Char = '\n'

    var customers = 10

// Some customers leave the queue
    customers = 8

    customers = customers + 3 // Example of addition: 11
    customers += 7            // Example of addition: 18
    customers -= 3            // Example of subtraction: 15
    customers *= 2            // Example of multiplication: 30
    customers /= 3            // Example of division: 10

    println(customers) // 10

    // Variable declared without initialization
    val d1: Int
// Variable initialized
    d1 = 3

// Variable explicitly typed and initialized
    val e1: String = "hello"

// Variables can be read because they have been initialized
    println(d1) // 3
    println(e1) // hello

}