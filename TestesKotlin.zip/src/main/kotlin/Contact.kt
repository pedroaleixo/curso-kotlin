/*
If the constructor has annotations or visibility modifiers, the constructor keyword is required and the modifiers go before it:

class Contact public @Inject constructor(val id: Int, var email: String = "test") {
 */

class Contact(val id: Int, var email: String = "test") {
    var name: String = "Holmes, Sherlock"
    var street: String = "Baker"
    var city: String = "London"
    var state: String? = null
    var zip: String = "123456"


    init {
        println("First initializer block that prints $name")
    }

    constructor(id: Int, email: String, email2: String) : this(id,email) {

    }

    fun printId() {
        println(id)
    }
}

fun main() {
    val contact = Contact(1, "mary@gmail.com")

    // Prints the value of the property: email
    println(contact.email)
    // mary@gmail.com

    // Updates the value of the property: email
    contact.email = "jane@gmail.com"

    // Prints the new value of the property: email
    println(contact.email)
    // jane@gmail.com

    println("Their email address is: ${contact.email}")

    contact.printId()
}