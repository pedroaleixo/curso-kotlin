

data class UserData(val name: String, val id: Int)


fun main() {
    val user = UserData("Alex", 1)
    val secondUser = UserData("Alex", 1)
    val thirdUser = UserData("Max", 2)

// Compares user to second user
    println("user == secondUser: ${user == secondUser}")
// user == secondUser: true

// Compares user to third user
    println("user == thirdUser: ${user == thirdUser}")
// user == thirdUser: false


    // Creates an exact copy of user
    println(user.copy())
// User(name=Alex, id=1)

// Creates a copy of user with name: "Max"
    println(user.copy("Max"))
// User(name=Max, id=1)

// Creates a copy of user with id: 3
    println(user.copy(id = 3))
// User(name=Alex, id=3)
}